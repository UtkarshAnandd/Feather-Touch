// Reference state logic from the approved prototype (React-style component).
// Port to vanilla JS: same states, timings (6000ms, 40px swipe), and reduced-motion behaviour.
class Component extends DCLogic {
  constructor(props) {
    super(props);
    this.state = { i: 0, paused: false, cyc: 0 };
    this.sx = null;
  }
  componentDidMount() {
    var reduce = false;
    try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
    if (reduce) this.setState({ paused: true });
    this.arm();
  }
  componentWillUnmount() { clearInterval(this.t); }
  arm() {
    var self = this;
    clearInterval(this.t);
    this.t = setInterval(function () {
      if (!self.state.paused) self.setState({ i: (self.state.i + 1) % 3, cyc: self.state.cyc + 1 });
    }, 6000);
  }
  go(n) { this.setState({ i: (n + 3) % 3, cyc: this.state.cyc + 1 }); this.arm(); }
  renderVals() {
    var self = this, i = this.state.i, p = this.state.paused;
    var v = {
      next: function () { self.go(i + 1); },
      prev: function () { self.go(i - 1); },
      toggle: function () { self.setState({ paused: !p, cyc: p ? self.state.cyc + 1 : self.state.cyc }); self.arm(); },
      pd: function (e) { self.sx = e.clientX; },
      pu: function (e) {
        if (self.sx === null) return;
        var dx = e.clientX - self.sx; self.sx = null;
        if (dx < -40) self.go(i + 1); else if (dx > 40) self.go(i - 1);
      },
      pos: String(i + 1),
      ssCls: p ? 'is-paused' : 'is-playing',
      pauseLabel: p ? 'Play slideshow' : 'Pause slideshow',
      live: p ? 'polite' : 'off',
      mount: 'm' + i,
      cyc: (this.state.cyc % 2) ? 'cy-b' : 'cy-a',
      pauseShow: p ? 'hide' : '',
      playShow: p ? '' : 'hide'
    };
    for (var k = 0; k < 3; k++) {
      v['c' + k] = k === i ? 'is-on' : '';
      v['h' + k] = k === i ? 'false' : 'true';
      v['a' + k] = k === i ? 'true' : 'false';
      v['g' + k] = (function (n) { return function () { self.go(n); }; })(k);
    }
    return v;
  }
}
