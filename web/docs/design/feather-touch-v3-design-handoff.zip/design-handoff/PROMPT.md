# Task: Implement the approved Feather Touch V3 design

You are working in the Feather Touch Foundation School & Day Care Centre website repository (Eleventy + Nunjucks + JSON data in src/_data + plain CSS + minimal vanilla JS). The client has approved the V3 visual design. Implement it faithfully. This is an implementation task, not a design task.

## Ground rules
- Do not redesign. Match the approved layout, spacing, typography, colour and behaviour.
- Keep the architecture: Eleventy, Nunjucks, JSON data, plain CSS, vanilla JS. No React, Next.js, Tailwind, CSS frameworks, carousel libraries or UI kits.
- Never invent content: no ages, timings, fees, addresses, phone numbers, testimonials, statistics, awards, facilities or claims. All copy comes from src/_data or from the approved design. If a value is missing, render the CONTENT REQUIRED state described below.
- Use only the images in design-handoff/assets/. Never use stock, AI-generated, background-removed or edited photographs.
- Work on a new branch, feat/v3-design. Commit section by section with clear messages.

## Source of truth (design-handoff/, in priority order)
1. Feather-Touch-Website-Design-V3-Visual-Direction.pdf: the design exactly as the client approved it.
2. reference/screens/: 2x screenshots of every section at 1280px (d_*.jpg) and 390px (m_*.jpg). These are the visual targets.
3. reference/prototype.css: exact token values, sizes, spacing, radii and states. Port the values; do not copy its CSS sprites or container-query scaffolding.
4. reference/homepage.html and reference/mobile-menu.html: prototype markup (open in a browser at 1280px and 390px wide). Structural reference only.
5. reference/slideshow-behaviour.js: slideshow state logic to port to vanilla JS.

## Step 1: Audit, then plan (before editing anything)
Read eleventy.config.js, src/_includes/layouts/base.njk, src/_includes/partials/ (header.njk, footer.njk, icons.njk), src/index.njk, src/assets/css/main.css, src/assets/js/main.js and every file in src/_data/ (site, navigation, about, programmes, dayCare, activities, daySequence, faq, images, recognition, testimonials, build.js). Output a short plan mapping each homepage section to its partial, data file(s) and any missing fields. Flag any conflict between the data and the design. Then implement.

## Design tokens (values from prototype.css)
- Colours: paper #FFF6E6 (page background), paper-raised #FFFBF3, paper-deep #F6E7CA, kraft #F1DDB8, line #E2CFA8, ink #1E3A2B (all text), ink-soft #4A5A4E, marigold #E88640, marigold-hover #F1964F, marigold-ledge #B5601F, marigold-display #C1570F, marigold-tint #FFE5C2, marigold-soft #FFD29B, leaf #A9CF48, leaf-2 #C8E283, leaf-3 #DDEDB0, leaf-tint #EEF6D6, leaf-deep #3E6A12, navy #22305A, flag #6B551F, flag-line #B9A06A.
- Colour rules: marigold and leaf are fills only, never text. marigold-display is for display text 40px and larger only. Navy is used only in the Safety section. Primary button = marigold fill with ink text and a 4px marigold-ledge bottom edge. No gradients, blobs, glassmorphism, emoji or additional colours.
- Type: Bricolage Grotesque (variable; display weight 760, font-stretch 88%), Atkinson Hyperlegible Next (body 18/1.55, lead 20, interface 16-17 bold), Fredoka (accent only: tape captions, slide tabs, "Step n" labels, one-line notes; never headings or paragraphs). Self-host the woff2 files in design-handoff/fonts/ with font-display: swap and preload Bricolage and Atkinson.
- Radii: 5px paper and posters, 14px buttons and controls, 18px shelves and forms, 22px photos.

## Playful elements (only where specified)
- Paper mount: a coloured sheet rotated 1.5-3 degrees behind photos and posters.
- Paper-tape caption: Fredoka, ragged clip-path, rotated -2 degrees.
- Brush stroke (assets/brush-lime.png): under "happy." in the hero and under the current navigation item only.
- Marker strike: the Why statement only.
- Leaf-in-hand mark (assets/mark-leaf-in-hand.png): Day Care only.
- Footprints: Admissions only.
- Nothing else decorative.

## Sections (match the screens; data sources in brackets)
1. Header [site.json, navigation.json]: rounded raised bar, logo plus "Foundation School & Day Care Centre", seven navigation items, primary CTA "Book a school visit". Full navigation at 1200px and wider; a "Menu" button below that.
2. Mobile menu: a real <button> with aria-expanded and aria-controls opening the full-screen panel shown in m_nav. Focus moves into the panel; Escape and Close return focus to the button; background scrolling is locked.
3. Hero [verified approach and about copy]: H1 "We believe children learn best when they are happy." with the second clause in marigold-display and the brush under "happy."; lead paragraph; two CTAs. Desktop: copy left, 4:5 slideshow right (472px wide). Mobile order: copy, CTAs, "Swipe to look around", slideshow.
4. Slideshow [images.json]: exactly three slides in this order: hero-welcome, hero-puzzle, hero-colouring. Use the captions and alt text in images.json (add missing entries; do not rewrite existing ones).
   - Timing: 6 seconds per slide, 0.8-second crossfade.
   - Paper mount colour changes per slide: leaf, marigold, marigold-soft.
   - "1 / 3" counter as an ink chip bottom-left, beside the tape caption.
   - Previous/next buttons bottom-right: 48px on desktop, 44px on mobile.
   - Shelf below the photo: WELCOME / PLAY / CREATE thumbnail tabs, a progress bar, and a pause/play button.
   - Manual navigation restarts the timer.
   - Swipe threshold 40px, with touch-action: pan-y on the frame.
   - prefers-reduced-motion: start paused, no transitions, full static progress bar.
   - Accessibility: aria-roledescription "carousel" and "slide"; aria-current on the active tab; inactive slides aria-hidden; a polite live region only while paused. Pause must always be available.
5. Why Feather Touch [about.json]: large statement with the marker strike over "pressure or rote learning", lead paragraph, link.
6. Programmes [programmes.json]:
   - Desktop: four-step staircase (block heights 170/206/242/278px, leaf-tint to leaf, ruler ticks, ink baseline) with name, tagline, full focus-area list, age and timings flags, and a link.
   - Mobile: blocks at 74/82/91/100% width. Focus areas and flags sit inside a native <details> ("n focus areas, age and timings"), closed by default, with a 48px summary.
7. Day Care [dayCare.json]:
   - Marigold-tint band: tape eyebrow "Day Care Centre", 80px heading, lead, pull quote with the leaf-in-hand mark, two-column includes list, secondary CTA.
   - Right column: 4:5 photo slot on a marigold mount (ASSET REQUIRED until a real Day Care photograph is supplied), with a practical-details shelf beneath it (Hours, Age range, Meals, Pickup).
8. School Life [activities.json, images.json]:
   - Heading and lead.
   - Four groups: Celebrations; Nature and healthy habits; Making and performing; Learning by doing. Add a "group" field to activities.json; do not reorder entries or imply dates.
   - Poster wall: the Janmashtami and World Environment Day posters on mounts with tape strips.
   - Mobile: the posters become a horizontal scroll-snap strip. This is the only intended horizontal scroll.
9. Children's Work: real artwork detail on a marigold mount with a tape caption; heading and lead beside it; four ASSET REQUIRED slots.
10. A Day at Feather Touch [daySequence.json]: centred heading; nine numbered marigold circles on a dashed line (a vertical list on mobile); timings flag.
11. Safety [safety data in src/_data]: navy band, heading, lead, italic note, two-column topics list, and a CONTENT REQUIRED panel for the school's safety practices.
12. Parent Partnership: "Parents + Teachers = Stronger foundations" equation heading, list, closing line.
13. Admissions: leaf-tint band; "Book a school visit"; contact rows; footprints; visit form (name, phone, programme radios, preferred time). No delivery endpoint exists: do not connect any third-party service; show the integration-required state on submit.
14. FAQ [faq.json]: native <details>, first item open.
15. Footer: ink band, logo, tagline, visit and contact flags, explore links.

## CONTENT REQUIRED / ASSET REQUIRED states
Build one partial per state, using the dashed style from prototype.css. Show them in development builds. In production builds, fail the build with a clear list of any unresolved item (extend src/_data/build.js and the existing launch flags). Never hide gaps silently and never ship placeholder text.
Outstanding today:
- Content: admissions session; programme ages and timings; Day Care hours, ages, meals and pickup; daily timings; school safety practices; phone, WhatsApp, email, address and visiting hours; privacy policy; form delivery.
- Assets: vector logo; parental consent for every child photograph; poster usage rights; a Day Care photograph; additional artwork.

## Images and performance
- Use <img> (not CSS sprites) with explicit width and height, srcset/sizes, and AVIF/WebP output. Use @11ty/eleventy-img if acceptable; otherwise pre-generate the files.
- First hero image: loading="eager" and fetchpriority="high". All other images: loading="lazy".
- The logo is an interim PNG until the vector file arrives.
- Total JavaScript about 6 KB or less, with no dependencies. No layout shift.

## Responsive and accessibility
- Mobile-first media queries.
- Verify at 320, 390, 430, 768, 1024, 1280 and 1440+.
- No horizontal overflow except the poster strip.
- Touch targets of at least 44px.
- One h1 and a logical heading order.
- Visible focus ring: 3px ink with a 3px offset; paper-coloured on dark bands.
- WCAG 2.2 AA contrast, and meaningful alt text from images.json.

## SEO
- Title and meta description from site.json.
- Semantic sections with aria-labelledby.
- JSON-LD only with verified fields (no address or phone until confirmed).
- No review or rating markup.

## Do not change
- Pages other than the homepage, apart from the shared header and footer.
- Build tooling, except for adding image processing.
- Existing JSON content values.
- Anything not specified above.

## Acceptance and testing
- Playwright screenshots at 1280px and 390px for every section, compared side by side with reference/screens. Report every visible deviation.
- Slideshow tests: autoplay at 6 seconds, next, previous, pause holds, resume, keyboard (Enter and Space on tabs and arrows), swipe both directions, a small drag ignored, reduced motion starts paused.
- Mobile menu tests: open, Escape, focus return, scroll lock.
- Programmes <details>: opens and closes by tap and by keyboard.
- Lighthouse mobile: accessibility 100, performance 90 or higher, CLS below 0.05.
- npm run build passes in development. The production build fails and lists the outstanding items above; this is expected until the client supplies them.

Finish with a report covering: files changed, any deviation from the design and why, test results, and the outstanding content and asset list.
