Copy the design-handoff folder into the root of the Feather Touch repository, then give Claude Code the prompt in PROMPT.md.
